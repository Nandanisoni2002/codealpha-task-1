import csv
from datetime import datetime
from scapy.all import sniff, IP, TCP, UDP, Raw

# Define the log file name
LOG_FILE = "packet_logs.csv"

# Create CSV file and write headers if it does not exist
def create_log_file():
    """Creates the CSV file and writes headers if not already present."""
    try:
        with open(LOG_FILE, mode="x", newline="") as file:
            writer = csv.writer(file)
            writer.writerow(["Timestamp", "Source IP", "Destination IP", "Protocol", "Source Port", "Destination Port", "Payload"])
    except FileExistsError:
        pass  # If file exists, do nothing

# Call the function to ensure the file is ready
create_log_file()

def packet_callback(packet):
    """Processes captured packets and logs them to a CSV file."""
    
    # Extract packet details
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    src_ip = packet[IP].src if IP in packet else "N/A"
    dst_ip = packet[IP].dst if IP in packet else "N/A"
    protocol = packet[IP].proto if IP in packet else "N/A"
    src_port = packet[TCP].sport if TCP in packet else (packet[UDP].sport if UDP in packet else "N/A")
    dst_port = packet[TCP].dport if TCP in packet else (packet[UDP].dport if UDP in packet else "N/A")
    payload = packet[Raw].load.decode(errors="ignore") if Raw in packet else "N/A"

    # Print the packet details to console
    print(f"\n--- Packet Captured at {timestamp} ---")
    print(f"Source IP: {src_ip} --> Destination IP: {dst_ip}")
    print(f"Protocol: {protocol}, Source Port: {src_port}, Destination Port: {dst_port}")
    print(f"Payload: {payload}")

    # Append packet details into the CSV file
    with open(LOG_FILE, mode="a", newline="") as file:
        writer = csv.writer(file)
        writer.writerow([timestamp, src_ip, dst_ip, protocol, src_port, dst_port, payload])

def start_sniffing(interface="eth0", packet_count=10):
    """Starts the sniffer on a specific interface for a given number of packets."""
    print(f"[*] Capturing packets on {interface}, logging to {LOG_FILE}...")
    sniff(iface=interface, prn=packet_callback, store=False, count=packet_count)
    print(f"[*] Packet capture complete. Logs saved in {LOG_FILE}")

if __name__ == "__main__":
    interface_name = input("Enter network interface (e.g., eth0, wlan0, lo): ")
    packet_limit = int(input("Enter the number of packets to capture: "))
    start_sniffing(interface_name, packet_limit)
